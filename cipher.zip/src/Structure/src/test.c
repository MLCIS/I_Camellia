#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int
main(int argc,char ** argv){
	printf("size : %lu\n"	,sizeof(unsigned char));
	return 0;
}	
